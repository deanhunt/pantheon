INSTALLATION

- Open Chrome browser
- Go to this URL: chrome://extensions/
- Check "Developer mode" to expand developer options
- Click "Load unpacked extension..."
- Select downloaded Patheon extension directory on your computer